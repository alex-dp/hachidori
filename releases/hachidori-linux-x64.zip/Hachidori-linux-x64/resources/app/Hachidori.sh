./Hachidori --disable-gpu --enable-transparent-visuals
