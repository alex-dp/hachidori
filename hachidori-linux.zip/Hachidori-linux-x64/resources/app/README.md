#Hachidori *(ハチドリ)*

Hachidori is a programmable desktop widget.

This is what it looks like:

<img src="./images/scrot.png">

###Compiling

package with electron,

precompiled packages coming soon i guess