#Hachidori *(ハチドリ)*

Hachidori is a programmable desktop widget.

This is what it looks like:

<img src="./images/scrot.png">

look under `releases` for precompiled packages.
#####I need a windows installer so if anyone could make one for me I'd be thankful.

####Installation
#####Linux
Extract `hachidori-linux-x64.zip` wherever you want and execute `INSTALL.sh`. done.

####Compilation

package with electron-packager  

you can find it in npm

#Hachidori is released under the GNU GPLv3 in case you didn't notice from the file called LICENCE