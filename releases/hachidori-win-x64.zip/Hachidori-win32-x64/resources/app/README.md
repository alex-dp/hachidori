#Hachidori *(ハチドリ)*

Hachidori is a programmable desktop widget.

This is what it looks like:

<img src="./images/scrot.png">

###Compilation

package with electron-packager  

you can find it in npm

####Execution

for linux, download hachidori-linux.zip, extract and run Hachidori.sh